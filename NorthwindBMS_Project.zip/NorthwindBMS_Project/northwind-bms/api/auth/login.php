<?php
// api/auth/login.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once "../config/Database.php";
require_once "../config/JWT.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => false, "message" => "Method Not Allowed"]);
    exit;
}

// รับข้อมูลจาก JSON Body หรือ POST Form
$data = json_decode(file_get_contents("php://input"), true);
$username = $data['username'] ?? $_POST['username'] ?? '';
$password = $data['password'] ?? $_POST['password'] ?? '';

if (empty($username) || empty($password)) {
    http_response_code(400);
    echo json_encode(["status" => false, "message" => "กรุณากรอก Username และ Password"]);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // ค้นหาผู้ใช้งานจากตาราง tb_users
    $sql = "SELECT * FROM tb_users WHERE c_usr_uname = :username LIMIT 1";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(":username", $username, PDO::PARAM_STR);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $user = $stmt->fetch();

        // ตรวจสอบ Password (รองรับทั้งแบบ Hash และ Plain Text)
        $isPasswordValid = password_verify($password, $user['c_usr_pwd']) || ($password === $user['c_usr_pwd']);

        if ($isPasswordValid) {
            // ดึงค่า ID โดยรองรับทั้งคอลัมน์ c_usr_id และ i_usr_id
            $userId = $user['c_usr_id'] ?? $user['i_usr_id'] ?? $user['id'] ?? 1;

            // สร้าง JWT Payload
            $payload = [
                "user_id" => $userId,
                "username" => $user['c_usr_uname'],
                "exp" => time() + (86400 * 7) // หมดอายุใน 7 วัน
            ];

            $token = JWT::encode($payload);

            http_response_code(200);
            echo json_encode([
                "status" => true,
                "message" => "เข้าสู่ระบบสำเร็จ",
                "token" => $token,
                "user" => [
                    "id" => $userId,
                    "username" => $user['c_usr_uname']
                ]
            ]);
        } else {
            http_response_code(401);
            echo json_encode(["status" => false, "message" => "รหัสผ่านไม่ถูกต้อง"]);
        }
    } else {
        http_response_code(404);
        echo json_encode(["status" => false, "message" => "ไม่พบชื่อผู้ใช้นี้ในระบบ"]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => false, "message" => "Database Error: " . $e->getMessage()]);
}