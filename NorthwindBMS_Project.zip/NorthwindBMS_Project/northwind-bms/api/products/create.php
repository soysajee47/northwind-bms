<?php
// api/products/create.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "../config/Database.php";
require_once "../config/JWT.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => false, "message" => "Method Not Allowed"]);
    exit;
}

$headers = function_exists('getallheaders') ? getallheaders() : [];
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';

if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthenticated"]);
    exit;
}

if (!JWT::decode($matches[1])) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthorized"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data['ProductName'])) {
    http_response_code(400);
    echo json_encode(["status" => false, "message" => "กรุณากรอกชื่อสินค้า"]);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    $sql = "INSERT INTO tb_products (ProductName, QuantityPerUnit, UnitPrice, UnitsInStock) VALUES (:name, :unit, :price, :stock)";
    $stmt = $db->prepare($sql);
    $stmt->execute([
        ':name' => $data['ProductName'],
        ':unit' => $data['QuantityPerUnit'] ?? '',
        ':price' => $data['UnitPrice'] ?? 0.00,
        ':stock' => $data['UnitsInStock'] ?? 0
    ]);

    http_response_code(201);
    echo json_encode(["status" => true, "message" => "เพิ่มสินค้าสำเร็จ"]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => false, "message" => "Database Error: " . $e->getMessage()]);
}