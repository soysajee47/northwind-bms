<?php
// api/products/update.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT, POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "../config/Database.php";
require_once "../config/JWT.php";

if ($_SERVER['REQUEST_METHOD'] !== 'PUT' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => false, "message" => "Method Not Allowed"]);
    exit;
}

$headers = function_exists('getallheaders') ? getallheaders() : [];
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';

if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthenticated"]);
    exit;
}

if (!JWT::decode($matches[1])) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthorized"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data['ProductID']) || empty($data['ProductName'])) {
    http_response_code(400);
    echo json_encode(["status" => false, "message" => "ข้อมูลไม่ครบถ้วน"]);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    $sql = "UPDATE tb_products SET ProductName = :name, QuantityPerUnit = :unit, UnitPrice = :price, UnitsInStock = :stock WHERE ProductID = :id";
    $stmt = $db->prepare($sql);
    $stmt->execute([
        ':name' => $data['ProductName'],
        ':unit' => $data['QuantityPerUnit'] ?? '',
        ':price' => $data['UnitPrice'] ?? 0.00,
        ':stock' => $data['UnitsInStock'] ?? 0,
        ':id' => $data['ProductID']
    ]);

    http_response_code(200);
    echo json_encode(["status" => true, "message" => "อัปเดตข้อมูลสินค้าสำเร็จ"]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => false, "message" => "Database Error: " . $e->getMessage()]);
}