<?php
// api/reports/sales.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
require_once "../config/Database.php";
require_once "../config/JWT.php";

$headers = getallheaders();
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';

if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $m) || !JWT::decode($m[1])) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthorized"]);
    exit;
}

try {
    $db = (new Database())->getConnection();
    $sql = "SELECT o.OrderID, o.OrderDate, o.TotalAmount, c.CompanyName 
            FROM tb_orders o 
            LEFT JOIN tb_customers c ON o.CustomerID = c.CustomerID 
            ORDER BY o.OrderID DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    
    echo json_encode(["status" => true, "data" => $stmt->fetchAll()]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => false, "message" => $e->getMessage()]);
}