<?php
// api/customers/delete.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: DELETE, POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "../config/Database.php";
require_once "../config/JWT.php";

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => false, "message" => "Method Not Allowed"]);
    exit;
}

$headers = function_exists('getallheaders') ? getallheaders() : [];
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';

if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthenticated"]);
    exit;
}

if (!JWT::decode($matches[1])) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthorized"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data['CustomerID'])) {
    http_response_code(400);
    echo json_encode(["status" => false, "message" => "ไม่พบ CustomerID"]);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    $sql = "DELETE FROM tb_customers WHERE CustomerID = :id";
    $stmt = $db->prepare($sql);
    $stmt->execute([':id' => $data['CustomerID']]);

    http_response_code(200);
    echo json_encode(["status" => true, "message" => "ลบข้อมูลลูกค้าเรียบร้อย"]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => false, "message" => "Database Error: " . $e->getMessage()]);
}