<?php
// api/customers/read.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "../config/Database.php";
require_once "../config/JWT.php";

// ตรวจสอบ HTTP Method
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["status" => false, "message" => "Method Not Allowed"]);
    exit;
}

// ตรวจสอบ Header สำหรับ JWT Token
$headers = function_exists('getallheaders') ? getallheaders() : [];
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';

if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthenticated: ไม่พบ JWT Token"]);
    exit;
}

$token = $matches[1];

try {
    // ถอดรหัส Token เพื่อตรวจสอบสิทธิ์
    $payload = JWT::decode($token);
    if (!$payload) {
        http_response_code(401);
        echo json_encode(["status" => false, "message" => "Unauthorized: Token ไม่ถูกต้องหรือหมดอายุ"]);
        exit;
    }

    $database = new Database();
    $db = $database->getConnection();

    // ดึงข้อมูลลูกค้า (รองรับทั้งชื่อตาราง tb_customers และ customers)
    try {
        $query = "SELECT * FROM tb_customers ORDER BY CustomerID ASC LIMIT 100";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $customers = $stmt->fetchAll();
    } catch (PDOException $e) {
        $query = "SELECT * FROM customers ORDER BY CustomerID ASC LIMIT 100";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $customers = $stmt->fetchAll();
    }

    http_response_code(200);
    echo json_encode([
        "status" => true,
        "message" => "ดึงข้อมูลลูกค้าสำเร็จ",
        "data" => $customers
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["status" => false, "message" => "Server Error: " . $e->getMessage()]);
}