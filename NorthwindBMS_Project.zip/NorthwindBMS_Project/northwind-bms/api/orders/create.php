<?php
// api/orders/create.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "../config/Database.php";
require_once "../config/JWT.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => false, "message" => "Method Not Allowed"]);
    exit;
}

$headers = function_exists('getallheaders') ? getallheaders() : [];
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';

if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthenticated"]);
    exit;
}

if (!JWT::decode($matches[1])) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthorized"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data['CustomerID']) || empty($data['items']) || !is_array($data['items'])) {
    http_response_code(400);
    echo json_encode(["status" => false, "message" => "กรุณาเลือกลูกค้าและเพิ่มรายการสินค้าอย่างน้อย 1 รายการ"]);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // เริ่ม Transaction เพื่อความปลอดภัยของข้อมูล
    $db->beginTransaction();

    // 1. บันทึกหัวข้อออเดอร์
    $sqlOrder = "INSERT INTO tb_orders (CustomerID, TotalAmount, Status) VALUES (:customer_id, 0.00, 'Completed')";
    $stmtOrder = $db->prepare($sqlOrder);
    $stmtOrder->execute([':customer_id' => $data['CustomerID']]);
    $orderId = $db->lastInsertId();

    $totalAmount = 0.00;

    // 2. ลูปบันทึกรายการสินค้าและตัดสต็อก
    $sqlDetail = "INSERT INTO tb_order_details (OrderID, ProductID, UnitPrice, Quantity) VALUES (:order_id, :product_id, :price, :qty)";
    $stmtDetail = $db->prepare($sqlDetail);

    $sqlStock = "UPDATE tb_products SET UnitsInStock = UnitsInStock - :qty WHERE ProductID = :product_id";
    $stmtStock = $db->prepare($sqlStock);

    foreach ($data['items'] as $item) {
        $pId = $item['ProductID'];
        $price = floatval($item['UnitPrice']);
        $qty = intval($item['Quantity']);

        $subtotal = $price * $qty;
        $totalAmount += $subtotal;

        // บันทึกลง tb_order_details
        $stmtDetail->execute([
            ':order_id' => $orderId,
            ':product_id' => $pId,
            ':price' => $price,
            ':qty' => $qty
        ]);

        // ตัดสต็อกสินค้าใน tb_products
        $stmtStock->execute([
            ':qty' => $qty,
            ':product_id' => $pId
        ]);
    }

    // 3. อัปเดตราคารวมสุทธิลงใน tb_orders
    $sqlUpdateTotal = "UPDATE tb_orders SET TotalAmount = :total WHERE OrderID = :order_id";
    $stmtUpdateTotal = $db->prepare($sqlUpdateTotal);
    $stmtUpdateTotal->execute([
        ':total' => $totalAmount,
        ':order_id' => $orderId
    ]);

    // ยืนยันการทำรายการทั้งหมด
    $db->commit();

    http_response_code(201);
    echo json_encode([
        "status" => true,
        "message" => "เปิดรายการสั่งซื้อสำเร็จและอัปเดตสต็อกเรียบร้อยแล้ว",
        "order_id" => $orderId
    ]);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    http_response_code(500);
    echo json_encode(["status" => false, "message" => "Transaction Failed: " . $e->getMessage()]);
}