<?php
// api/orders/detail.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "../config/Database.php";
require_once "../config/JWT.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["status" => false, "message" => "Method Not Allowed"]);
    exit;
}

$headers = function_exists('getallheaders') ? getallheaders() : [];
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';

if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthenticated"]);
    exit;
}

if (!JWT::decode($matches[1])) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthorized"]);
    exit;
}

$orderId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($orderId <= 0) {
    http_response_code(400);
    echo json_encode(["status" => false, "message" => "ไม่พบรหัสรายการสั่งซื้อ"]);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // 1. ดึงข้อมูลหัวข้อออเดอร์ + ข้อมูลลูกค้า
    $sqlOrder = "SELECT o.OrderID, o.OrderDate, o.TotalAmount, o.Status,
                        c.CompanyName, c.ContactName, c.Phone, c.City, c.Country
                 FROM tb_orders o
                 LEFT JOIN tb_customers c ON o.CustomerID = c.CustomerID
                 WHERE o.OrderID = :order_id";
    $stmtOrder = $db->prepare($sqlOrder);
    $stmtOrder->execute([':order_id' => $orderId]);
    $order = $stmtOrder->fetch();

    if (!$order) {
        http_response_code(404);
        echo json_encode(["status" => false, "message" => "ไม่พบข้อมูลรายการสั่งซื้อ"]);
        exit;
    }

    // 2. ดึงรายการสินค้าในออเดอร์
    $sqlItems = "SELECT od.OrderDetailID, od.ProductID, od.UnitPrice, od.Quantity,
                        (od.UnitPrice * od.Quantity) AS Subtotal,
                        p.ProductName, p.QuantityPerUnit
                 FROM tb_order_details od
                 LEFT JOIN tb_products p ON od.ProductID = p.ProductID
                 WHERE od.OrderID = :order_id";
    $stmtItems = $db->prepare($sqlItems);
    $stmtItems->execute([':order_id' => $orderId]);
    $items = $stmtItems->fetchAll();

    http_response_code(200);
    echo json_encode([
        "status" => true,
        "data" => [
            "order" => $order,
            "items" => $items
        ]
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => false, "message" => "Database Error: " . $e->getMessage()]);
}