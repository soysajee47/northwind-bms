<?php
// api/config/Database.php
class Database {
    private $host = "sql104.infinityfree.com";
    private $db_name = "if0_43305596_northwind";
    private $username = "if0_43305596";
    private $password = "M3kKjOb18gn";
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8",
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $exception) {
            echo json_encode(["status" => false, "message" => "Database Connection Error: " . $exception->getMessage()]);
            exit;
        }
        return $this->conn;
    }
}