<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
require_once "../config/Database.php";
require_once "../config/JWT.php";

$headers = getallheaders();
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';

if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $m) || !JWT::decode($m[1])) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthorized"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$db = (new Database())->getConnection();
$stmt = $db->prepare("UPDATE tb_categories SET CategoryName = :name, Description = :desc WHERE CategoryID = :id");
$stmt->execute([':name' => $data['CategoryName'], ':desc' => $data['Description'] ?? '', ':id' => $data['CategoryID']]);
echo json_encode(["status" => true, "message" => "แก้ไขหมวดหมู่สำเร็จ"]);