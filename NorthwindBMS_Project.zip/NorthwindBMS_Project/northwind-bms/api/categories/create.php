<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
require_once "../config/Database.php";
require_once "../config/JWT.php";

$headers = getallheaders();
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';

if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $m) || !JWT::decode($m[1])) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthorized"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
if (empty($data['CategoryName'])) {
    http_response_code(400);
    echo json_encode(["status" => false, "message" => "กรุณากรอกชื่อหมวดหมู่"]);
    exit;
}

$db = (new Database())->getConnection();
$stmt = $db->prepare("INSERT INTO tb_categories (CategoryName, Description) VALUES (:name, :desc)");
$stmt->execute([':name' => $data['CategoryName'], ':desc' => $data['Description'] ?? '']);
echo json_encode(["status" => true, "message" => "เพิ่มหมวดหมู่สำเร็จ"]);