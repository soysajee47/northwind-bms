<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
require_once "../config/Database.php";
require_once "../config/JWT.php";

$headers = getallheaders();
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $m) || !JWT::decode($m[1])) {
    http_response_code(401); echo json_encode(["status" => false, "message" => "Unauthorized"]); exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$db = (new Database())->getConnection();
$stmt = $db->prepare("INSERT INTO tb_employees (FirstName, LastName, Title, Phone) VALUES (:fname, :lname, :title, :phone)");
$stmt->execute([
    ':fname' => $data['FirstName'],
    ':lname' => $data['LastName'],
    ':title' => $data['Title'] ?? '',
    ':phone' => $data['Phone'] ?? ''
]);
echo json_encode(["status" => true, "message" => "เพิ่มพนักงานสำเร็จ"]);