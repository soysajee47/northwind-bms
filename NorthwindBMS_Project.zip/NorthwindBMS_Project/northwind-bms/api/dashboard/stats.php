<?php
// api/dashboard/stats.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once "../config/Database.php";
require_once "../config/JWT.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["status" => false, "message" => "Method Not Allowed"]);
    exit;
}

$headers = function_exists('getallheaders') ? getallheaders() : [];
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';

if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthenticated"]);
    exit;
}

if (!JWT::decode($matches[1])) {
    http_response_code(401);
    echo json_encode(["status" => false, "message" => "Unauthorized"]);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // 1. สรุปตัวเลข การ์ด 4 ใบ
    $totalSales = $db->query("SELECT IFNULL(SUM(TotalAmount), 0) AS total FROM tb_orders")->fetch()['total'];
    $totalOrders = $db->query("SELECT COUNT(*) AS total FROM tb_orders")->fetch()['total'];
    $totalCustomers = $db->query("SELECT COUNT(*) AS total FROM tb_customers")->fetch()['total'];
    $totalProducts = $db->query("SELECT COUNT(*) AS total FROM tb_products")->fetch()['total'];

    // 2. สถานะสต็อกสินค้า (สำหรับ Chart)
    $inStock = $db->query("SELECT COUNT(*) AS total FROM tb_products WHERE UnitsInStock > 10")->fetch()['total'];
    $lowStock = $db->query("SELECT COUNT(*) AS total FROM tb_products WHERE UnitsInStock BETWEEN 1 AND 10")->fetch()['total'];
    $outOfStock = $db->query("SELECT COUNT(*) AS total FROM tb_products WHERE UnitsInStock = 0")->fetch()['total'];

    // 3. สินค้าขายดี Top 5 (สำหรับ Chart)
    $queryTop = "SELECT p.ProductName, IFNULL(SUM(od.Quantity), 0) AS total_sold
                 FROM tb_products p
                 LEFT JOIN tb_order_details od ON p.ProductID = od.ProductID
                 GROUP BY p.ProductID, p.ProductName
                 ORDER BY total_sold DESC LIMIT 5";
    $topProducts = $db->query($queryTop)->fetchAll();

    http_response_code(200);
    echo json_encode([
        "status" => true,
        "data" => [
            "summary" => [
                "totalSales" => floatval($totalSales),
                "totalOrders" => intval($totalOrders),
                "totalCustomers" => intval($totalCustomers),
                "totalProducts" => intval($totalProducts)
            ],
            "stockStatus" => [
                "inStock" => intval($inStock),
                "lowStock" => intval($lowStock),
                "outOfStock" => intval($outOfStock)
            ],
            "topProducts" => $topProducts
        ]
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["status" => false, "message" => "Database Error: " . $e->getMessage()]);
}